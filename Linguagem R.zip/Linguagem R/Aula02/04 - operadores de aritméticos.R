####################################################
#                                                  #  
# Módulo 2 - Tipos de dados e operadores           #
#                                                  #
# Vídeo 04 - Operadores matemáticos                #
#                                                  #
####################################################
# adição
1 + 1

# subtração
4 - 2

# multiplicação
2 * 3

# divisão
5 / 3

# potência
4 ^ 2

# resto da divisão de 5 por 3
5 %% 3

# parte inteira da divisão de 5 por 3
5 %/% 3  

# expoente 4 por 2
4 ** 2