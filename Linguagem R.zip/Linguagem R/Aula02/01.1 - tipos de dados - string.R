####################################################
#                                                  #  
# Módulo 2 - Tipos de dados e operadores           #
#                                                  #
# Vídeo 01 - Tipos de dados - character (string)   #
#                                                  #
####################################################

# Declarando váriáveis (simbolo de atribuição)
var1 <- "Olá mundo" 
typeof(var1)
class(var1)

assign("var2","Sejam bem vindos") 
typeof(var2)
class(var2)

# Declaração
var3 <- "10" 
typeof(var3)
class(var3)