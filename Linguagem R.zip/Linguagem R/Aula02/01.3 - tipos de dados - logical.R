####################################################
#                                                  #  
# Módulo 2 - Tipos de dados e operadores           #
#                                                  #
# Vídeo 01 - Tipos de dados - logical (TRUE/FALSE) #
#                                                  #
####################################################

# Declarando váriáveis (simbolo de atribuição)
var1 <- TRUE
var2 <- T
typeof(var1)
typeof(var2)
